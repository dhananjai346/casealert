# CaseAlert AI Bot 🚀

This repo contains:
- `main.py` : CaseAlert AI Telegram bot
- `scraper.py` : Scraper for court cases
- `payments.py` : UPI payment integration
- `marketing_bot.py` : Marketing automation

## Deployment
1. Push to GitHub
2. Deploy to Railway (Dockerfile included)
3. Set ENV vars: BOT_TOKEN, PRICE, UPI_ID
