def handle_payment(user_id: int, amount: int):
    # TODO: Integrate UPI collection
    return f"Payment request of {amount} sent to user {user_id}"
